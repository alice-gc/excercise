@extends('layouts.app')

@section('content')

<div class="d-flex flex-column shadow-lg w-100 p-3" style="padding:2%;height:350px!important">
  <div class="container">
    <div class="row">
      <div class="col">
        <a href="https://play.google.com/store/apps/details?id=live.cupof.exercise">
          https://play.google.com/store/apps/details?id=live.cupof.exercise</a>

      </div>
    </div>
    <div class="row">
      <div class="col">

        <a href="https://play.google.com/apps/testing/live.cupof.exercise">
          https://play.google.com/apps/testing/live.cupof.exercise
        </a>

      </div>
    </div>
    <div class="row">
      <div class="col">
        <a href="https://github.com/alice-gc/excercise">
          https://github.com/alice-gc/excercise
        </a>
      </div>
    </div>

  </div>
</div>
@endsection