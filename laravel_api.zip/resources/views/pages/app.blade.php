https://play.google.com/store/apps/details?id=live.cupof.exercise

readme here