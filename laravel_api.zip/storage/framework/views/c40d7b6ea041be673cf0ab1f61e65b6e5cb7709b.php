

<?php $__env->startSection('content'); ?>

<div class="d-flex flex-column shadow-lg w-100 p-3" style="padding:2%;height:350px!important">
  <div class="container">
    <div class="row">
      <div class="col">
        <a href="https://play.google.com/store/apps/details?id=live.cupof.exercise">
          https://play.google.com/store/apps/details?id=live.cupof.exercise</a>

      </div>
    </div>
    <div class="row">
      <div class="col">

        <a href="https://play.google.com/apps/testing/live.cupof.exercise">
          https://play.google.com/apps/testing/live.cupof.exercise
        </a>

      </div>
    </div>
    <div class="row">
      <div class="col">
        <a href="https://github.com/alice-gc/excercise">
          https://github.com/alice-gc/excercise
        </a>
      </div>
    </div>

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\excercise\laravel_api\resources\views/pages/links.blade.php ENDPATH**/ ?>