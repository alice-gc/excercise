<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">
  <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
  </link>

  <title>Cup of Calisthenics</title>

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
</head>

<body>
  <!-- navbar -->
  <?php echo $__env->make('components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <main>
    <div class="container shadow-lg">
      <?php echo $__env->yieldContent('content'); ?>
    </div>
  </main>

  <!-- footer -->
  <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</body>
</body>

</html><?php /**PATH C:\xampp\htdocs\excercise\laravel_api\resources\views/layouts/app.blade.php ENDPATH**/ ?>