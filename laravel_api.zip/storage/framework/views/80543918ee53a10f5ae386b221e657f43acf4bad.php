https://play.google.com/store/apps/details?id=live.cupof.exercise

readme here<?php /**PATH C:\xampp\htdocs\excercise\laravel_api\resources\views/pages/app.blade.php ENDPATH**/ ?>